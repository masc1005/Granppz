 <!--                                           

    AREA DE PHP

-->
<?php session_start(); ?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Granppz</title>
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/main.css">
    <link rel="shortcut icon" href="../logo/pp.png" type="image/x-png">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>
<body>
    <div class="home">
        <div class="row">
            <div class="col-md-12 text-center">
                <br>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12 text-center">
                <br>
                <a href="../view/publi.php"><img src="../logo/granppz.png" width="175"></a>
            </div>
        </div>
        <hr/>
        <div class="row">
            <div class="col-md-4 text-center text-shadow">
                <a href="../view/publi.php"> PUBLICAÇÕES </a>
            </div>
            <div class="col-md-4 text-center text-shadow">
                <a href="../view/feed.php"> MEU PERFIL </a>
            </div>
            <div class="col-md-4 text-center">
                <a href="../view/songs.php"> MUSICAS </a>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-4 text-center bg-dark">
            <br>
    <!--                                           

    AREA DE PHP

-->
<div class="user">
    <div class="card" style="width: 15rem;">
        <img class="card-img-top" src="../logo/avatar.png" >
        <div class="card-body">
        </div>
        <ul class="list-group list-group-flush">
            <h5 class="card-title"><!--    USER!!!        --></h5>
            <li class="list-group-item"><!-- nome e sobrenome --></li>
            <li class="list-group-item"><!--- nascimento  dd/mm/aaaa  ---></li>
            <li class="list-group-item"><a href="../view/home.php"> LOG OUT </a></li>
        </ul>

    </div>
</div>
</div>
<div class="col-md-4">
    <form  method="post" action="../control/postar.php">
        <div class="form-group">
            <label for="exampleFormControlTextarea1"><b>Em que a musica te inspirou hoje?</b></label><br>
            
            <label for="exampleFormControlTextarea1"> Titulo</label>
            <div class="input_titulo_feed">
                <textarea class="form-control" name="titulo" width="50" id="exampleFormControlTextarea1" rows=""></textarea>
            </div>
            <label for="exampleFormControlTextarea1"> Texto</label>
            <textarea class="form-control" name="texto" id="exampleFormControlTextarea1" rows="3"></textarea>
        </div>
        <button type="submit" class="btn btn-secondary align-content-right">Publicar</button>
    </form>
    <br>
    <div class="post-content">
        <hr/>
        <h4> ... </h4>
        <span class="text-muted small"><i class fa-user></i> <?php echo $_SESSION['user']."  - "; ?> <i class="fa-lock"></i> <?php 

        require_once '../control/Conexao.php';

        $sql = "SELECT dataPost FROM postar WHERE id_postar = (SELECT MAX(id_postar) FROM postar)";
        $result = mysqli_query($conexao, $sql);

        while($rows = mysqli_fetch_array($result)) {

            echo $rows['dataPost'];
            //echo $rows['nome'];

            //$_SESSION['teste'] = $rows['data_criado'];
        }

        //$dataEHora = '../view/feed.php'; date_default_timezone_set('America/Sao_Paulo'); $date = filemtime($dataEHora); echo date('d/m/Y \à\s H:i:s', ($date));

        //date_default_timezone_set('America/Sao_Paulo'); echo $dataLocal = date('d/m/Y H:i:s', time());?> </span>

        <div class="media">
            <div clas="media-body">
                <img src="../logo/pp.png">

                <p>
                    <?php

                    $nome = $_SESSION['user'];
                    require_once '../control/Conexao.php';

                    $sql = "SELECT * FROM postar WHERE nomeUser = '$nome' ";
                    //$sql = "SELECT * FROM cadastro INNER JOIN postar ON cadastro.id_cad = postar.nomeUser ";
                    $result = mysqli_query($conexao, $sql);

                    while($rows = mysqli_fetch_array($result)) {

                        echo "<br>";
                        echo $rows['texto'];
                    }

                    ?>

                </p>
                <br>


                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modalExemplo">
                    leia mais
                </button>

                <div class="modal fade" id="modalExemplo" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Título do modal</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Fechar">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <img src="../logo/pp.png">
                                <p>     
                                    <?php

                                    /*require_once '../control/Conexao.php';

                                    $sql = "SELECT * FROM postar";
                                    $result = mysqli_query($conexao, $sql);

                                    while($rows = mysqli_fetch_array($result)) {

                                        echo $rows['texto']."<br>";
                                    }*/


                                    $nome = $_SESSION['user'];
                                    require_once '../control/Conexao.php';

                                    $sql = "SELECT * FROM postar WHERE nomeUser = '$nome' ";
                                    //$sql = "SELECT * FROM cadastro INNER JOIN postar ON cadastro.id_cad = postar.nomeUser ";
                                    $result = mysqli_query($conexao, $sql);

                                    while($rows = mysqli_fetch_array($result)) {

                                        echo "<br>";
                                        echo $rows['texto'];
                                    }



                                    ?>

                                </p>
                                <br>
                            </div>
                            <div class="modal-footer">
                                <div class="col-md-3">
                                    <i class="material-icons">thumb_up</i>
                                    <i class="material-icons">thumbs_up_down</i>
                                    <i class="material-icons">thumb_down</i>
                                </div>
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- <div class="post-content">
        <hr/>
        <h4> ... </h4>
        <span class="text-muted small"><i class fa-user></i>Leoni Lucas -<i class="fa-lock"></i>
        25/11/2019 às 15:10</span>
        <div class="media">
            <div clas="media-body">
                <img src="../logo/pp.png">

                <p>TextoTextoTextoTextoTextoTextoTextoTextoTextoTextoTexto
                    TextoTextoTextoTextoTextoTextoTextoTextoTextoTextoTexto
                    TextoTextoTextoTextoTextoTextoTextoTextoTextoTextoTexto
                    TextoTextoTextoTextoTextoTextoTextoTextoTextoTextoTexto
                    TextoTextoTextoTextoTextoTextoTextoTextoTextoTextoTexto
                    TextoTextoTextoTextoTextoTextoTextoTextoTextoTextoTexto
                TextoTextoTextoTextoTextoTextoTextoTextoTextoTextoTexto                    </p>
                <br>

                
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modalExemplo">
                    leia mais
                </button>

                
                <div class="modal fade" id="modalExemplo" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                       <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Título do modal</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Fechar">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <img src="../logo/pp.png">

                            <p>TextoTextoTextoTextoTextoTextoTextoTextoTextoTextoTexto
                                TextoTextoTextoTextoTextoTextoTextoTextoTextoTextoTexto
                                TextoTextoTextoTextoTextoTextoTextoTextoTextoTextoTexto
                                TextoTextoTextoTextoTextoTextoTextoTextoTextoTextoTexto
                                TextoTextoTextoTextoTextoTextoTextoTextoTextoTextoTexto
                                TextoTextoTextoTextoTextoTextoTextoTextoTextoTextoTexto
                            TextoTextoTextoTextoTextoTextoTextoTextoTextoTextoTexto</p>
                            <br>
                        </div>
                        <div class="modal-footer">
                            <div class="text-left">
                                <i class="material-icons">thumb_up</i>
                                <i class="material-icons">thumbs_up_down</i>
                                <i class="material-icons">thumb_down</i>
                            </div>
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div> -->

</div>

<div class="col-md-4 bg-dark">

</div>
</div>
<script src='../js/jquery-3.4.1.min.js'></script>
<script src='../js/bootstrap.min.js'></script>
</body>
</html>